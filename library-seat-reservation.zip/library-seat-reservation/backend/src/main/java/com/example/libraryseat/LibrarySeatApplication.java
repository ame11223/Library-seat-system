package com.example.libraryseat;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.*;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import java.util.Base64;

@SpringBootApplication
@EnableScheduling
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class LibrarySeatApplication implements WebMvcConfigurer {
    private final JdbcTemplate db;
    private final TransactionTemplate tx;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    private final String secret;
    private final int tokenHours;

    public LibrarySeatApplication(JdbcTemplate db, TransactionTemplate tx,
            @org.springframework.beans.factory.annotation.Value("${app.jwt-secret}") String secret,
            @org.springframework.beans.factory.annotation.Value("${app.token-hours:12}") int tokenHours) {
        this.db=db; this.tx=tx; this.secret=secret; this.tokenHours=tokenHours;
    }

    public static void main(String[] args) { SpringApplication.run(LibrarySeatApplication.class,args); }

    @Bean CommandLineRunner seed() {
        return args -> {
            if (db.queryForObject("SELECT COUNT(*) FROM app_user", Integer.class)==0) {
                addUser("admin","123456","ADMIN");
                addUser("20240001","123456","STUDENT");
                addUser("20240002","123456","STUDENT");
                addUser("20240003","123456","STUDENT");
            }
            if (db.queryForObject("SELECT COUNT(*) FROM seat", Integer.class)==0) {
                for (int i=1;i<=50;i++) {
                    int floor=(i-1)/20+1, room=(i-1)/10+1;
                    db.update("INSERT INTO seat(seat_no,floor_no,room_no,status) VALUES(?,?,?,'AVAILABLE')",
                        String.format("S%03d",i), floor+"F", "R"+room);
                }
            }
        };
    }
    private void addUser(String account,String password,String role) {
        db.update("INSERT INTO app_user(account,password_hash,role) VALUES(?,?,?)",account,encoder.encode(password),role);
    }

    @Override public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new org.springframework.web.servlet.HandlerInterceptor() {
            public boolean preHandle(HttpServletRequest req, jakarta.servlet.http.HttpServletResponse res, Object handler) throws Exception {
                String path=req.getRequestURI();
                if (path.equals("/api/auth/login") || path.equals("/error") || req.getMethod().equals("OPTIONS")) return true;
                String header=req.getHeader("Authorization");
                if (header==null || !header.startsWith("Bearer ")) { res.setStatus(401); res.getWriter().write("{\"message\":\"请先登录\"}"); return false; }
                try {
                    Map<String,String> claims=verify(header.substring(7));
                    req.setAttribute("uid",Long.parseLong(claims.get("uid")));
                    req.setAttribute("role",claims.get("role"));
                    return true;
                } catch(Exception e) { res.setStatus(401); res.getWriter().write("{\"message\":\"登录凭证无效或已过期\"}"); return false; }
            }
        }).addPathPatterns("/api/**");
    }
    private long uid(HttpServletRequest r) { return (Long)r.getAttribute("uid"); }
    private String role(HttpServletRequest r) { return (String)r.getAttribute("role"); }
    private void admin(HttpServletRequest r) { if (!"ADMIN".equals(role(r))) throw new ApiError(403,"无权访问管理员功能"); }
    private void student(HttpServletRequest r) { if (!"STUDENT".equals(role(r))) throw new ApiError(403,"仅学生可以执行预约操作"); }
    private Map<String,Object> ok(Object data) { return Map.of("success",true,"data",data==null?Map.of():data); }
    private Map<String,Object> row(Map<String,Object> m) { return m; }

    @PostMapping("/auth/login")
    public Map<String,Object> login(@RequestBody Map<String,String> body) {
        String account=body.getOrDefault("account",""), password=body.getOrDefault("password","");
        List<Map<String,Object>> users=db.queryForList("SELECT id,account,password_hash,role FROM app_user WHERE account=?",account);
        if(users.isEmpty() || !encoder.matches(password,(String)users.get(0).get("PASSWORD_HASH")))
            throw new ApiError(401,"账号或密码错误");
        Map<String,Object> u=users.get(0);
        String token=issue(((Number)u.get("ID")).longValue(),(String)u.get("ROLE"));
        return ok(Map.of("token",token,"account",u.get("ACCOUNT"),"role",u.get("ROLE")));
    }

    @GetMapping("/seats")
    public Map<String,Object> seats(@RequestParam String date,@RequestParam String startTime,@RequestParam String endTime,
        @RequestParam(required=false) String floor,@RequestParam(required=false) String room) {
        LocalDate d=LocalDate.parse(date); LocalTime s=LocalTime.parse(startTime), e=LocalTime.parse(endTime);
        if(!e.isAfter(s)) throw new ApiError(400,"结束时间必须晚于开始时间");
        LocalDateTime start=d.atTime(s), end=d.atTime(e);
        String sql="SELECT s.*, CASE WHEN EXISTS (SELECT 1 FROM seat_reservation r WHERE r.seat_id=s.id AND r.status IN ('CONFIRMED','CHECKED_IN') AND r.start_at < ? AND r.end_at > ?) THEN FALSE ELSE TRUE END AS available FROM seat s WHERE s.status='AVAILABLE'";
        List<Object> args=new ArrayList<>(List.of(end,start));
        if(floor!=null&&!floor.isBlank()){sql+=" AND s.floor_no=?";args.add(floor);}
        if(room!=null&&!room.isBlank()){sql+=" AND s.room_no=?";args.add(room);}
        sql+=" ORDER BY s.floor_no,s.room_no,s.seat_no";
        return ok(db.queryForList(sql,args.toArray()));
    }

    @PostMapping("/reservations")
    public Map<String,Object> reserve(HttpServletRequest req,@RequestBody Map<String,String> body) {
        student(req);
        long seatId=Long.parseLong(body.get("seatId"));
        LocalDate date=LocalDate.parse(body.get("date"));
        LocalDateTime start=date.atTime(LocalTime.parse(body.get("startTime")));
        LocalDateTime end=date.atTime(LocalTime.parse(body.get("endTime")));
        if(!end.isAfter(start) || !start.isAfter(LocalDateTime.now().minusMinutes(1))) throw new ApiError(400,"预约时间无效");
        Long id=tx.execute(status -> {
            List<Map<String,Object>> seats=db.queryForList("SELECT id,status FROM seat WHERE id=? FOR UPDATE",seatId);
            if(seats.isEmpty()) throw new ApiError(404,"座位不存在");
            if(!"AVAILABLE".equals(seats.get(0).get("STATUS"))) throw new ApiError(409,"座位正在维护");
            Integer count=db.queryForObject("SELECT COUNT(*) FROM seat_reservation WHERE seat_id=? AND status IN ('CONFIRMED','CHECKED_IN') AND start_at < ? AND end_at > ?",Integer.class,seatId,end,start);
            if(count!=null&&count>0) throw new ApiError(409,"该时段已被预约");
            org.springframework.jdbc.support.GeneratedKeyHolder keys = new org.springframework.jdbc.support.GeneratedKeyHolder();
            db.update(connection -> {
                java.sql.PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO seat_reservation(user_id,seat_id,start_at,end_at,status) VALUES(?,?,?,?, 'CONFIRMED')",
                    java.sql.Statement.RETURN_GENERATED_KEYS);
                ps.setLong(1, uid(req));
                ps.setLong(2, seatId);
                ps.setTimestamp(3, java.sql.Timestamp.valueOf(start));
                ps.setTimestamp(4, java.sql.Timestamp.valueOf(end));
                return ps;
            }, keys);
            return Objects.requireNonNull(keys.getKey()).longValue();
        });
        return ok(Map.of("reservationId",id,"status","CONFIRMED"));
    }

    @GetMapping("/reservations/mine")
    public Map<String,Object> mine(HttpServletRequest req) {
        student(req);
        return ok(db.queryForList("SELECT r.*,s.seat_no,s.floor_no,s.room_no FROM seat_reservation r JOIN seat s ON s.id=r.seat_id WHERE r.user_id=? ORDER BY r.start_at DESC",uid(req)));
    }

    @PostMapping("/reservations/{id}/check-in")
    public Map<String,Object> checkin(HttpServletRequest req,@PathVariable long id) {
        return transition(req,id,"checkin");
    }
    @PostMapping("/reservations/{id}/cancel")
    public Map<String,Object> cancel(HttpServletRequest req,@PathVariable long id) { return transition(req,id,"cancel"); }
    @PostMapping("/reservations/{id}/complete")
    public Map<String,Object> complete(HttpServletRequest req,@PathVariable long id) { return transition(req,id,"complete"); }

    private Map<String,Object> transition(HttpServletRequest req,long id,String action) {
        student(req);
        return tx.execute(status -> {
            List<Map<String,Object>> rows=db.queryForList("SELECT * FROM seat_reservation WHERE id=? FOR UPDATE",id);
            if(rows.isEmpty()) throw new ApiError(404,"预约不存在");
            Map<String,Object> r=rows.get(0);
            if(((Number)r.get("USER_ID")).longValue()!=uid(req)) throw new ApiError(403,"不能操作他人的预约");
            String state=(String)r.get("STATUS");
            LocalDateTime start=((java.sql.Timestamp)r.get("START_AT")).toLocalDateTime();
            LocalDateTime now=LocalDateTime.now();
            if(action.equals("checkin")) {
                if(!state.equals("CONFIRMED")) throw new ApiError(409,"当前预约状态不能签到");
                if(now.isBefore(start)||!now.isBefore(start.plusMinutes(15))) throw new ApiError(400,"签到仅允许在预约开始后15分钟内完成");
                db.update("UPDATE seat_reservation SET status='CHECKED_IN',checked_in_at=? WHERE id=? AND status='CONFIRMED'",now,id);
                return ok(Map.of("status","CHECKED_IN"));
            }
            if(action.equals("cancel")) {
                if(!state.equals("CONFIRMED")||!now.isBefore(start)) throw new ApiError(409,"仅可在预约开始前取消未签到预约");
                db.update("UPDATE seat_reservation SET status='CANCELLED' WHERE id=? AND status='CONFIRMED'",id);
                return ok(Map.of("status","CANCELLED"));
            }
            if(!state.equals("CHECKED_IN")) throw new ApiError(409,"只有签到后才能结束使用");
            db.update("UPDATE seat_reservation SET status='COMPLETED' WHERE id=? AND status='CHECKED_IN'",id);
            return ok(Map.of("status","COMPLETED"));
        });
    }

    @GetMapping("/admin/seats")
    public Map<String,Object> adminSeats(HttpServletRequest req) { admin(req); return ok(db.queryForList("SELECT * FROM seat ORDER BY floor_no,room_no,seat_no")); }
    @PostMapping("/admin/seats")
    public Map<String,Object> addSeat(HttpServletRequest req,@RequestBody Map<String,String> b) {
        admin(req);
        db.update("INSERT INTO seat(seat_no,floor_no,room_no,status) VALUES(?,?,?,?)",b.get("seatNo"),b.get("floor"),b.get("room"),b.getOrDefault("status","AVAILABLE"));
        return ok(Map.of("message","座位已新增"));
    }
    @PutMapping("/admin/seats/{id}")
    public Map<String,Object> updateSeat(HttpServletRequest req,@PathVariable long id,@RequestBody Map<String,String> b) {
        admin(req);
        db.update("UPDATE seat SET seat_no=?,floor_no=?,room_no=?,status=? WHERE id=?",b.get("seatNo"),b.get("floor"),b.get("room"),b.getOrDefault("status","AVAILABLE"),id);
        return ok(Map.of("message","座位已更新"));
    }
    @DeleteMapping("/admin/seats/{id}")
    public Map<String,Object> deleteSeat(HttpServletRequest req,@PathVariable long id) {
        admin(req);
        Integer active=db.queryForObject("SELECT COUNT(*) FROM seat_reservation WHERE seat_id=? AND status IN ('CONFIRMED','CHECKED_IN')",Integer.class,id);
        if(active!=null&&active>0) throw new ApiError(409,"该座位存在有效预约，不能删除");
        db.update("DELETE FROM seat WHERE id=?",id); return ok(Map.of("message","座位已删除"));
    }
    @GetMapping("/admin/no-shows")
    public Map<String,Object> noShows(HttpServletRequest req) {
        admin(req);
        return ok(db.queryForList("SELECT r.*,u.account,s.seat_no,s.floor_no,s.room_no FROM seat_reservation r JOIN app_user u ON u.id=r.user_id JOIN seat s ON s.id=r.seat_id WHERE r.status='NO_SHOW' ORDER BY r.start_at DESC"));
    }
    @GetMapping("/admin/stats")
    public Map<String,Object> stats(HttpServletRequest req) {
        admin(req);
        LocalDate d=LocalDate.now();
        Integer total=db.queryForObject("SELECT COUNT(*) FROM seat_reservation WHERE CAST(start_at AS DATE)=?",Integer.class,java.sql.Date.valueOf(d));
        Integer noshow=db.queryForObject("SELECT COUNT(*) FROM seat_reservation WHERE CAST(start_at AS DATE)=? AND status='NO_SHOW'",Integer.class,java.sql.Date.valueOf(d));
        Integer using=db.queryForObject("SELECT COUNT(*) FROM seat_reservation WHERE status='CHECKED_IN'",Integer.class);
        return ok(Map.of("todayReservations",total,"todayNoShows",noshow,"currentlyUsing",using));
    }

    @Scheduled(fixedDelay=60000)
    public void releaseNoShows() {
        LocalDateTime now=LocalDateTime.now();
        db.update("UPDATE seat_reservation SET status='NO_SHOW' WHERE status='CONFIRMED' AND start_at <= ?",now.minusMinutes(15));
    }

    private String issue(long uid,String role) {
        long exp=Instant.now().plusSeconds(tokenHours*3600L).getEpochSecond();
        String payload=uid+"|"+role+"|"+exp;
        String p=Base64.getUrlEncoder().withoutPadding().encodeToString(payload.getBytes(StandardCharsets.UTF_8));
        return p+"."+sign(p);
    }
    private Map<String,String> verify(String token) throws Exception {
        String[] parts=token.split("\\.");
        if(parts.length!=2||!sign(parts[0]).equals(parts[1])) throw new Exception("signature");
        String[] c=new String(Base64.getUrlDecoder().decode(parts[0]),StandardCharsets.UTF_8).split("\\|");
        if(c.length!=3||Long.parseLong(c[2])<Instant.now().getEpochSecond()) throw new Exception("expired");
        return Map.of("uid",c[0],"role",c[1]);
    }
    private String sign(String value) {
        try {
            Mac mac=Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(value.getBytes(StandardCharsets.UTF_8)));
        } catch(Exception e) { throw new IllegalStateException(e); }
    }

    @RestControllerAdvice
    static class Errors {
        @ExceptionHandler(ApiError.class) ResponseEntity<Map<String,Object>> api(ApiError e) {
            return ResponseEntity.status(e.status).body(Map.of("success",false,"message",e.getMessage()));
        }
        @ExceptionHandler(Exception.class) ResponseEntity<Map<String,Object>> other(Exception e) {
            return ResponseEntity.status(500).body(Map.of("success",false,"message","服务器处理失败"));
        }
    }
    static class ApiError extends RuntimeException {
        final int status;
        ApiError(int status,String message){super(message);this.status=status;}
    }
}
