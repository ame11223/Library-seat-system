## macOS 一键启动（本地 H2 模式）

先安装 JDK 17+、Maven、Node.js。安装 Homebrew 后可在终端执行：
```bash
brew install openjdk@17 maven node
```
JDK 17 配置：Apple Silicon 通常使用 `/opt/homebrew/opt/openjdk@17`，Intel 通常使用 `/usr/local/opt/openjdk@17`。若 `java -version` 未检测到 JDK，请按 Homebrew 输出提示配置 `JAVA_HOME`。

解压后，在项目目录的终端执行：
```bash
chmod +x start-mac.command
./start-mac.command
```
或通过 Finder 右键打开 `start-mac.command`。首次会安装依赖并下载 Maven 包（需要联网）。后端日志写入 `backend.log`。浏览器打开 `http://localhost:5173`。退出时按 Ctrl+C。

若提示 Maven 未找到，运行 `brew install maven`；若提示 npm 未找到，运行 `brew install node`。

> 说明：此版本尚未在真实 macOS 上编译验证。Mac 一键脚本为便利启动入口，不保证任何电脑上零配置运行。脚本启动后端进程可能需要在退出后使用 `lsof -i :8080` 检查残留服务。

# 图书馆座位预约管理系统

基于 Spring Boot 3 + Vue 3 的独立座位预约项目。已移除图书借阅、图书检索、阅读笔记、书单等模块，只保留学生预约、签到、取消、结束使用及管理员管理功能。

## 技术栈
- 后端：Java 17、Spring Boot 3.2、Spring JDBC、Spring Scheduling
- 前端：Vue 3、Vite、Element Plus、Axios
- 数据库：H2 演示数据库（默认）、MySQL 8（生产/验收）
- 认证：JWT 风格 HMAC-SHA256 Bearer Token，密码 BCrypt
- 并发控制：事务 + `SELECT ... FOR UPDATE` 锁定座位行，再检查时间段重叠

## 快速启动（Windows / macOS / Linux）
### 1. 后端
需要 JDK 17+、Maven 3.8+。
```bash
cd backend
mvn spring-boot:run
```
默认 H2 文件数据库，后端地址 `http://localhost:8080`。

切换 MySQL：
1. 创建数据库 `library_seat`。
2. 设置环境变量 `DB_URL=jdbc:mysql://localhost:3306/library_seat?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Shanghai`、`DB_USERNAME`、`DB_PASSWORD`。
3. 设置 `SPRING_PROFILES_ACTIVE=mysql`，再启动后端。

### 2. 前端
需要 Node.js 18+。
```bash
cd frontend
npm install
npm run dev
```
访问 `http://localhost:5173`。Vite 会将 `/api` 转发到后端 8080。

## 初始账号
首次启动时自动创建（密码均为 `123456`）：
- 管理员：`admin`
- 学生：`20240001`、`20240002`、`20240003`

首次登录后请修改默认密码（当前版本提供 BCrypt 存储；密码修改接口可在后续扩展）。

## 功能
- 学生/管理员登录，角色鉴权
- 按日期、开始时间、结束时间、楼层、房间查询空闲座位
- 预约指定座位，后端事务锁座并防止时间重叠
- 预约开始前取消
- 开始时间至开始时间 + 15 分钟内签到（左闭右开）
- 已签到预约结束使用
- 每分钟将超过签到窗口仍为 CONFIRMED 的预约标记为 NO_SHOW
- 管理员座位增删改查、违约记录、今日预约/违约/使用中统计
- 自动初始化 1 个管理员、3 个学生、至少 50 个座位

## API 摘要
| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/auth/login` | 登录 |
| GET | `/api/seats` | 查询空闲座位，参数 date/startTime/endTime/floor/room |
| POST | `/api/reservations` | 创建预约 |
| GET | `/api/reservations/mine` | 我的预约 |
| POST | `/api/reservations/{id}/check-in` | 签到 |
| POST | `/api/reservations/{id}/cancel` | 取消 |
| POST | `/api/reservations/{id}/complete` | 结束使用 |
| GET/POST/PUT/DELETE | `/api/admin/seats` | 管理座位 |
| GET | `/api/admin/no-shows` | 违约记录 |
| GET | `/api/admin/stats` | 今日统计 |

除登录接口外，所有接口均需在请求头携带 `Authorization: Bearer <token>`。管理员接口仅 ADMIN 角色可访问。

## 关键业务规则
1. 时间段按 `[开始时间, 结束时间)` 判断是否重叠：`existing.start_at < requested.end_at AND existing.end_at > requested.start_at`。
2. 创建预约时先开启事务并锁定对应座位行，随后检查维护状态和重叠预约；并发请求同一座位会串行检查。
3. 签到时间必须满足 `start_at <= now < start_at + 15 minutes`，在第 15 分钟整拒绝。
4. 定时任务每 60 秒执行：只更新状态仍为 `CONFIRMED` 且 `start_at + 15 minutes <= now` 的记录为 `NO_SHOW`。
5. 只有预约所有者可签到、取消、结束；取消仅允许在预约开始前。

## 测试建议
- 使用两个并发请求对同一座位、同一时间段预约：只允许一个成功。
- 在预约开始后 14:59 签到应成功；15:00 签到应失败。
- 创建预约但不签到，等待调度器执行或调用管理员数据核对 `NO_SHOW`。
- 使用学生 Token 请求 `/api/admin/seats`，应返回 403。

## 项目结构
```text
library-seat-reservation/
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/example/libraryseat/LibrarySeatApplication.java
│       └── resources/
│           ├── application.yml
│           ├── application-mysql.yml
│           └── schema.sql
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── main.js
│       └── App.vue
├── docs/
│   ├── API.md
│   └── STATE_MACHINE.md
└── LICENSE
```

## 来源与许可
本项目的需求依据用户提供的《图书馆预约系统.docx》。本压缩包是面向本需求重新整理的独立实现，借鉴了公开项目 `nasnawilson/smart-library` 的座位预约业务场景与技术方向；并非该仓库的逐文件 Fork 或源码删减版。上游仓库可在 https://github.com/nasnawilson/smart-library 查看。本项目不包含其图书借阅业务模块。


## macOS 预约失败排查
如果出现“服务器处理失败”，查看项目根目录中的 `backend.log`：
```bash
tail -n 100 ~/Downloads/library-seat-reservation/backend.log
```
本修订版已调整 H2 生成预约 ID 的读取方式，并在异常发生时打印详细堆栈。
