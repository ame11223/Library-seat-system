# 接口文档

统一前缀：`/api`。除 `POST /auth/login` 外，均需 `Authorization: Bearer <token>`。

## 登录
`POST /auth/login`
```json
{"account":"20240001","password":"123456"}
```
成功返回 `data.token`、`data.account`、`data.role`。

## 座位查询
`GET /seats?date=2026-11-25&startTime=09:00:00&endTime=11:00:00&floor=1F&room=R1`
楼层、房间可选。返回座位基础信息及 `AVAILABLE`（所选时间段是否空闲）。

## 预约
`POST /reservations`
```json
{"seatId":1,"date":"2026-11-25","startTime":"09:00:00","endTime":"11:00:00"}
```

## 我的预约
`GET /reservations/mine`

## 状态操作
- `POST /reservations/{id}/check-in`
- `POST /reservations/{id}/cancel`
- `POST /reservations/{id}/complete`

## 管理员接口（ADMIN）
- `GET /admin/seats`
- `POST /admin/seats`，请求体：`{"seatNo":"S051","floor":"3F","room":"R5","status":"AVAILABLE"}`
- `PUT /admin/seats/{id}`，字段同上
- `DELETE /admin/seats/{id}`
- `GET /admin/no-shows`
- `GET /admin/stats`

## 状态码
- 200：成功
- 400：参数或业务时间窗口不符合
- 401：未登录或 Token 无效
- 403：角色/资源权限不足
- 404：资源不存在
- 409：预约冲突或状态冲突
- 500：服务器异常
