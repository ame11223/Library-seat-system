# 预约状态机

```mermaid
stateDiagram-v2
    [*] --> Confirmed: 创建预约
    Confirmed --> Checked_in: 开始时间 <= 当前时间 < 开始时间+15分钟签到
    Confirmed --> Cancelled: 开始时间前主动取消
    Confirmed --> No_show: 超过开始时间+15分钟仍未签到
    Checked_in --> Completed: 结束使用
    Cancelled --> [*]
    No_show --> [*]
    Completed --> [*]
```

有效占用状态：`CONFIRMED`、`CHECKED_IN`。取消、违约、完成后，该预约不再阻止后续时段预约。

时间区间采用左闭右开 `[start_at, end_at)`，因此 09:00-10:00 与 10:00-11:00 可以首尾相接，不算冲突。
