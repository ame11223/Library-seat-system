#!/bin/bash
set -e
cd "$(dirname "$0")/frontend"
npm install --no-audit --no-fund
exec npm run dev
