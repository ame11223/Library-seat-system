<template>
  <div class="page">
    <header><div><h1>图书馆座位预约系统</h1><p>Library Seat Reservation</p></div>
      <div v-if="token" class="user">{{account}} · {{role==='ADMIN'?'管理员':'学生'}} <el-button size="small" @click="logout">退出</el-button></div>
    </header>
    <main v-if="!token" class="login">
      <el-card><h2>用户登录</h2><el-form @submit.prevent="login">
        <el-form-item label="账号"><el-input v-model="form.account" placeholder="请输入学号/管理员账号"/></el-form-item>
        <el-form-item label="密码"><el-input v-model="form.password" type="password" show-password @keyup.enter="login"/></el-form-item>
        <el-button type="primary" class="full" :loading="busy" @click="login">登录</el-button>
        <p class="hint">演示账号：admin / 123456；学生：20240001 / 123456</p>
      </el-form></el-card>
    </main>
    <main v-else>
      <el-tabs v-model="tab">
        <el-tab-pane label="查找座位" name="search">
          <el-card>
            <el-form inline>
              <el-form-item label="日期"><el-date-picker v-model="filter.date" value-format="YYYY-MM-DD" type="date"/></el-form-item>
              <el-form-item label="开始"><el-time-picker v-model="filter.startTime" value-format="HH:mm:ss" format="HH:mm"/></el-form-item>
              <el-form-item label="结束"><el-time-picker v-model="filter.endTime" value-format="HH:mm:ss" format="HH:mm"/></el-form-item>
              <el-form-item label="楼层"><el-select v-model="filter.floor" clearable placeholder="全部楼层"><el-option v-for="f in floors" :key="f" :label="f" :value="f"/></el-select></el-form-item>
              <el-form-item label="房间"><el-select v-model="filter.room" clearable placeholder="全部房间"><el-option v-for="r in rooms" :key="r" :label="r" :value="r"/></el-select></el-form-item>
              <el-button type="primary" @click="loadSeats">查询空闲座位</el-button>
            </el-form>
          </el-card>
          <div class="seat-grid">
            <el-card v-for="s in seats" :key="s.ID" class="seat-card">
              <div class="seat-no">{{s.SEAT_NO}}</div><p>{{s.FLOOR_NO}} · {{s.ROOM_NO}}</p>
              <el-tag :type="s.AVAILABLE?'success':'info'">{{s.AVAILABLE?'空闲':'已预约'}}</el-tag>
              <el-button v-if="s.AVAILABLE" type="primary" size="small" @click="reserve(s)">预约</el-button>
            </el-card>
          </div>
        </el-tab-pane>
        <el-tab-pane label="我的预约" name="mine">
          <el-button @click="loadMine">刷新</el-button>
          <el-table :data="mine" stripe>
            <el-table-column prop="SEAT_NO" label="座位"/><el-table-column prop="FLOOR_NO" label="楼层"/><el-table-column prop="ROOM_NO" label="房间"/>
            <el-table-column prop="START_AT" label="开始时间"/><el-table-column prop="END_AT" label="结束时间"/>
            <el-table-column prop="STATUS" label="状态"/>
            <el-table-column label="操作" min-width="230">
              <template #default="{row}">
                <el-button v-if="row.STATUS==='CONFIRMED'" size="small" type="success" @click="act(row,'check-in')">签到</el-button>
                <el-button v-if="row.STATUS==='CONFIRMED'" size="small" @click="act(row,'cancel')">取消</el-button>
                <el-button v-if="row.STATUS==='CHECKED_IN'" size="small" type="primary" @click="act(row,'complete')">结束使用</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane v-if="role==='ADMIN'" label="管理后台" name="admin">
          <div class="stats">
            <el-card><small>今日预约</small><h2>{{stats.todayReservations??'—'}}</h2></el-card>
            <el-card><small>今日违约</small><h2>{{stats.todayNoShows??'—'}}</h2></el-card>
            <el-card><small>当前使用中</small><h2>{{stats.currentlyUsing??'—'}}</h2></el-card>
          </div>
          <el-button @click="loadAdmin">刷新统计</el-button>
          <el-divider/>
          <h3>座位管理</h3>
          <el-form inline><el-input v-model="newSeat.seatNo" placeholder="座位号"/><el-input v-model="newSeat.floor" placeholder="楼层"/><el-input v-model="newSeat.room" placeholder="房间"/><el-button type="primary" @click="addSeat">新增座位</el-button></el-form>
          <el-table :data="adminSeats"><el-table-column prop="SEAT_NO" label="座位"/><el-table-column prop="FLOOR_NO" label="楼层"/><el-table-column prop="ROOM_NO" label="房间"/><el-table-column prop="STATUS" label="状态"/><el-table-column label="操作"><template #default="{row}"><el-button type="danger" size="small" @click="deleteSeat(row)">删除</el-button></template></el-table-column></el-table>
          <el-divider/><h3>违约记录</h3>
          <el-table :data="noShows"><el-table-column prop="ACCOUNT" label="学号"/><el-table-column prop="SEAT_NO" label="座位"/><el-table-column prop="START_AT" label="预约开始"/><el-table-column prop="STATUS" label="状态"/></el-table>
        </el-tab-pane>
      </el-tabs>
    </main>
    <el-dialog v-model="dialog" title="确认预约" width="420px">
      <p>预约座位：<b>{{selected?.SEAT_NO}}</b></p><p>{{filter.date}} {{filter.startTime}} - {{filter.endTime}}</p>
      <template #footer><el-button @click="dialog=false">取消</el-button><el-button type="primary" @click="confirmReserve">确认预约</el-button></template>
    </el-dialog>
    <el-alert v-if="message" :title="message" :type="messageType" closable @close="message=''" class="notice"/>
  </div>
</template>

<script setup>
import {ref,reactive,onMounted} from 'vue'
import axios from 'axios'
const token=ref(localStorage.getItem('token')||''), role=ref(localStorage.getItem('role')||''), account=ref(localStorage.getItem('account')||'')
const tab=ref('search'), busy=ref(false), message=ref(''), messageType=ref('success')
const form=reactive({account:'20240001',password:'123456'})
const pad=n=>String(n).padStart(2,'0')
const initial=new Date()
initial.setHours(initial.getHours()+1,0,0,0)
if(initial.getHours()===23) initial.setDate(initial.getDate()+1), initial.setHours(9)
const initialEnd=new Date(initial)
initialEnd.setHours(initialEnd.getHours()+1)
const today=`${initial.getFullYear()}-${pad(initial.getMonth()+1)}-${pad(initial.getDate())}`
const filter=reactive({date:today,startTime:`${pad(initial.getHours())}:00:00`,endTime:`${pad(initialEnd.getHours())}:00:00`,floor:'',room:''})
const floors=['1F','2F','3F'], rooms=['R1','R2','R3','R4','R5']
const seats=ref([]),mine=ref([]),adminSeats=ref([]),noShows=ref([]),stats=ref({})
const dialog=ref(false),selected=ref(null),newSeat=reactive({seatNo:'',floor:'1F',room:'R1'})
const api=axios.create({baseURL:'/api'})
api.interceptors.request.use(c=>{if(token.value)c.headers.Authorization=`Bearer ${token.value}`;return c})
api.interceptors.response.use(r=>r.data, e=>{throw new Error(e.response?.data?.message||'请求失败，请检查服务是否启动')})
function notify(msg,type='success'){message.value=msg;messageType.value=type}
async function login(){busy.value=true;try{const r=await api.post('/auth/login',form);token.value=r.data.token;role.value=r.data.role;account.value=r.data.account;localStorage.setItem('token',token.value);localStorage.setItem('role',role.value);localStorage.setItem('account',account.value);notify('登录成功');loadSeats();if(role.value==='ADMIN')loadAdmin()}catch(e){notify(e.message,'error')}finally{busy.value=false}}
function logout(){token.value='';role.value='';localStorage.clear()}
async function loadSeats(){try{const r=await api.get('/seats',{params:filter});seats.value=r.data}catch(e){notify(e.message,'error')}}
async function loadMine(){try{const r=await api.get('/reservations/mine');mine.value=r.data}catch(e){notify(e.message,'error')}}
function reserve(s){selected.value=s;dialog.value=true}
async function confirmReserve(){try{await api.post('/reservations',{seatId:selected.value.ID,date:filter.date,startTime:filter.startTime,endTime:filter.endTime});dialog.value=false;notify('预约成功');loadSeats();loadMine()}catch(e){notify(e.message,'error')}}
async function act(row,action){try{await api.post(`/reservations/${row.ID}/${action}`);notify('操作成功');loadMine();loadSeats()}catch(e){notify(e.message,'error')}}
async function loadAdmin(){try{const [a,b,c]=await Promise.all([api.get('/admin/stats'),api.get('/admin/seats'),api.get('/admin/no-shows')]);stats.value=a.data;adminSeats.value=b.data;noShows.value=c.data}catch(e){notify(e.message,'error')}}
async function addSeat(){try{await api.post('/admin/seats',newSeat);notify('新增成功');newSeat.seatNo='';loadAdmin()}catch(e){notify(e.message,'error')}}
async function deleteSeat(row){try{await api.delete(`/admin/seats/${row.ID}`);notify('删除成功');loadAdmin()}catch(e){notify(e.message,'error')}}
onMounted(()=>{if(token.value){loadSeats();loadMine();if(role.value==='ADMIN')loadAdmin()}})
</script>

<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6fa;color:#243247;font-family:Inter,"Microsoft YaHei",sans-serif}.page{max-width:1200px;margin:auto;padding:24px}header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}header h1{margin:0;font-size:26px}header p{margin:5px 0;color:#8792a5}.user{display:flex;gap:12px;align-items:center}.login{max-width:440px;margin:8vh auto}.login h2{margin-top:0}.full{width:100%}.hint{font-size:12px;color:#8993a4;margin-top:16px}.seat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px;margin-top:20px}.seat-card{text-align:center}.seat-no{font-size:24px;font-weight:700;color:#3568c0}.seat-card p{color:#78869b}.seat-card .el-button{display:block;margin:12px auto 0}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:18px 0}.stats h2{font-size:30px;margin:8px 0;color:#3568c0}.notice{position:fixed;right:24px;bottom:24px;width:min(420px,90vw);z-index:10}@media(max-width:700px){.page{padding:12px}.stats{grid-template-columns:1fr}header h1{font-size:20px}}
</style>
