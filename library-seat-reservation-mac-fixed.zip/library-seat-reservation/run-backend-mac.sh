#!/bin/bash
set -e
cd "$(dirname "$0")/backend"
exec mvn spring-boot:run
