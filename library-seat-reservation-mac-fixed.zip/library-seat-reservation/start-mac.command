#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v java >/dev/null; then
  echo "缺少 Java 17+。请先安装 JDK 17 或 21。"; read -r -p "回车退出..."; exit 1
fi
if ! command -v mvn >/dev/null; then
  echo "缺少 Maven。安装 Homebrew 后执行 brew install maven"; read -r -p "回车退出..."; exit 1
fi
if ! command -v npm >/dev/null; then
  echo "缺少 Node.js/npm。安装 Homebrew 后执行 brew install node"; read -r -p "回车退出..."; exit 1
fi
echo "启动后端（H2 演示数据库）..."
(cd backend && mvn spring-boot:run) > backend.log 2>&1 &
BACK_PID=$!
trap 'kill "$BACK_PID" 2>/dev/null || true' EXIT
sleep 8
if ! kill -0 "$BACK_PID" 2>/dev/null; then
  echo "后端启动失败，查看 backend.log"; tail -60 backend.log; read -r -p "回车退出..."; exit 1
fi
echo "安装前端依赖（首次需要联网）..."
cd frontend
npm install --no-audit --no-fund
echo "访问 http://localhost:5173 （Ctrl+C 结束）"
npm run dev -- --host 127.0.0.1
